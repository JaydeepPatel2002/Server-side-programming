# CWEB API ad UI Practice

A company makes a total of 12 different SKUs (Stock Keeping Unit). Some of the SKUs are the same product but in different sizes. For example, at a store you can buy shampoo in 600ml or the same shampoo in family size 1.2 L.

## Entity

Make a new entity call it Product, Add appropriate [column](https://typeorm.io/#/entities/column-options) types and sizes as well as appropriate [validation](https://www.npmjs.com/package/class-validator#manual-validation). Product should have:

- id -Auto generated starting with 5-digit number
- name – has emojis in the name – max 150 characters
- size – the quantity and unit (Example &quot;200 g&quot;) - max 10 characters
- price - per unit cost, max 2 decimal places

## Data Entry
Use DB Navigator to add 12 entries to the product table – make up any products

## Files and Code
 Create the following files:
- \product-ui.html - Vuejs - include all css and js resources 
- \src\controller\ProductController.ts - Controller path '/products' (you decide the actions and routes)

## App Requirements
**CAUTION only have the code that is absolutely required – extra (copy/paste) code will be considered incorrect**

From Time to Time the company will modify products including the name, but it will never add new products or remove products.

The company needs and app (Typeorm API and a [Vuejs](https://vuejs.org/v2/api/#Directives) UI)

1. The user needs a [select input](https://vuejs.org/v2/guide/forms.html#Select) to pick the product/size - use the id as the value for each option
2. The product list must be in alphabetical order by name then size (done either in the controller with [order by](https://typeorm.io/#/find-options) or in ui using [computed properties](https://vuejs.org/v2/guide/computed.html#Computed-Properties))
3. When a product is [selected](https://stackoverflow.com/questions/60397490/getting-selected-value-of-select-list-in-vue) the corresponding product is loaded in a html form, allowing the user to modify all fields except id
4. When the user clicks the submit button a PUT request is sent to the controller. When the user clicks cancel the page is reloaded.

