import {Column, Entity, PrimaryGeneratedColumn} from 'typeorm';
import {IsOptional, Length, IsInt, Min, Max, MaxLength, IsNotEmpty} from 'class-validator';

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  @IsOptional()
    id: number;

  // Exercise 12:  add column options to make firstName and age explicitly not nullable (aka required)
  @Column('nvarchar', {length: 50, nullable: false})
  @Length(1, 50, {message: 'First Name must be from $constraint1 to $constraint2 characters '})
  @IsNotEmpty({message: 'First Name is Required'})
    firstName: string;

  @Column('nvarchar', {length: 50, nullable: true})
  @MaxLength( 50, {message: 'Last Name must be at most $constraint1 characters '})
  @IsOptional()
    lastName: string;

  @Column('integer', {nullable: false})
  // Exercise 13: add constraints to age, only allow whole numbers from 1 to 120
  @Min(1, {message: 'Age must be 1 or more'})
  @Max(120, {message: 'Age must at most 120'})
  @IsInt({message: 'Age must be a whole number'})
    age: number;
}
