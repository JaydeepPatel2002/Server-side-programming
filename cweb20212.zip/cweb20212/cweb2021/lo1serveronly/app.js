var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const fs = require("fs");

const passport = require('passport');
const JwtStrategy = require('passport-jwt').Strategy;
// declare alias for Extractor - because we are not using the default Authenticate Header for the token
const ExtractJwt = require('passport-jwt').ExtractJwt;
passport.use( new JwtStrategy({
// look the token in the URL or BODY specifically the access_token parameter
          jwtFromRequest: ExtractJwt.fromExtractors([
            ExtractJwt.fromUrlQueryParameter('access_token'),
            ExtractJwt.fromBodyField('access_token'),
          ]),
          // specify the public key we need to decrypt the token
          secretOrKey: fs.readFileSync('es256public.pem'), // get file buffer of binary file data
          algorithm: 'ES256',
        },
        (payload, done)=>{ // verify handler
                           // ensure the role is allowed
          if (!['admin', 'employee', 'client'].includes(payload.role)) {
            // specify that the role is invalid
            return done(null, false, {message: 'Specified role is not allowed'} );
          }
          // ensure the scope is allowed
          if (!['dashboard', 'profile', 'booking'].includes(payload.scope)) {
            // specify that the scope is invalid
            return done(null, false, {message: 'Specified scope is not allowed'} );
          }
          // return a success notification to the passport process
          // normally we would use the payload to search a database then pass along a user object
          // - but for new we are passing along the payload from the JWT
          return done(null, payload);
        }),
);





var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
const examplesRouter = require('./routes/examples');
const FallRouter = require('./routes/fallsemester');
const secureRouter = require('./routes/secure');
const stateRouter = require('./routes/state');

var app = express();

const session = require('express-session');
const Sqlite = require('better-sqlite3'); // sqlite database driver
const SqliteStore = require('better-sqlite3-session-store')(session); // helps store session in an sqlite database
const sessOptions = {
    // set secret from environment variable used to encode the session cookie
    secret: 'shhhhhhh_this-is+SECret' , // should be the same for cookie-parser
    name: 'session-id', // name of the session cookie default: connect.sid
    resave: false, // store session after every request
    saveUninitialized: false, // if true sets a cookie even if no session info is stored
    cookie: {httpOnly: false, maxAge: 1000*60*60}, // cookie options - see cookie-parser docs
    unset: 'destroy', // instruction for stored session when unset
    store: new SqliteStore({ // a location to store session besides the memory
        client: new Sqlite('sessions.db', {verbose: console.log}),
        expired: {clear: true, intervalMs: 1000*60*15},
    }),
};



// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser(sessOptions.secret));
app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize({userProperty: 'currentUser'}));
app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/secure', secureRouter);
app.use('/bw', express.static(__dirname + '/node_modules/bootswatch/dist'));
app.use('/state',stateRouter);
app.use('/examples', examplesRouter);
app.use('/fallsemester', FallRouter);

// configure session session options
app.use(session(sessOptions));


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
