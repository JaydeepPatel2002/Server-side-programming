const express = require('express');
// eslint-disable-next-line new-cap
const router = express.Router();

<!--   ====================================                              =================================================================== -->
<!--   ====================================                              =================================================================== -->
<!--   ====================================   this is the exercise six   =================================================================== -->
<!--   ====================================                              =================================================================== -->
<!--   ====================================                              =================================================================== -->

// TODO: code to handle get request to roo examples path
/* GET content for path: http://localhost:3000/examples/ */
router.get('/', function(req, res, next) {
    // eslint-disable-next-line max-len
    // send content directly to the browser (not using a template) - this can be tedious
    // eslint-disable-next-line max-len
    res.render('fallsemester', {title: 'Fall semester'});
});



router.get('/courses', function(req, res, next) {
    res.render('courses', {
        title: 'GET - Simple Form Example',
        isSubmitted: req.query.agreed === 'yes', // check to see if the agreed url param is 'yes -  http://localhost:3000/examples/form/?agreed=yes
        // eslint-disable-next-line max-len
        // example localhost/examples/form/?someName=someValue then we use req.query.someName access the value of the URL parameter
        // eslint-disable-next-line max-len
        submittedName: req.query.name, // /examples/form/?someName=someValue&email=t%40t.ca then we use:  req.query.email
        // eslint-disable-next-line max-len
        submittedNumber: req.query.num, // /examples/form/?someName=someValue&pwd=passW0rd then we use:   req.query.pwd
        // eslint-disable-next-line max-len
        submittedDate: req.query.date, // /examples/form/?someName=someValue&agreed=yes then we use:  req.query.agreed
    });
});

// TODO: code to handle POST request to /examples/form/ path
/* POST submit form data to path : http://localhost:3000/examples/form */
router.post('/form', function(req, res, next) {
    res.render('courses', {
        title: 'POST - Simple Form Example',
        // eslint-disable-next-line max-len
        isSubmitted: req.body.agreed === 'yes', // check to see if user checked the checkbox <input name="agreed" value="yes" />
        // eslint-disable-next-line max-len
        // example <input name="someName" /> then we use req.body.someName access the user input value
        // eslint-disable-next-line max-len
        submittedName: req.body.name, // <input name="email" /> then we use:    req.body.email
        // eslint-disable-next-line max-len
        submittedNumber: req.body.num, // <input name="pwd" /> then we use:     req.body.pwd
        // eslint-disable-next-line max-len
        submittedDate: req.body.date, // <input name="agreed" value="yes" /> then we use:  req.body.agreed
        // submittedPhone: req.body.phone //part of exercise 3
    });
});



router.get('/courses', (req, res, next) => {
    res.render('courses', {
        title: 'My Courses',
    });
});

module.exports = router;